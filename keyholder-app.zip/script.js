
let model, webcam;

function log(message) {
    const logContent = document.querySelector('.log-content');
    const time = new Date().toLocaleTimeString();
    const logEntry = document.createElement('div');
    logEntry.innerHTML = `[${time}] ${message}`;
    logContent.appendChild(logEntry);
    logContent.scrollTop = logContent.scrollHeight;
    console.log(`[${time}] ${message}`);
}

// ページ読み込み時の初期化
document.addEventListener('DOMContentLoaded', () => {
    log('アプリケーションが起動しました');
    log('カメラを起動してから判定ボタンを押してください');
});

document.getElementById("start-camera").addEventListener("click", async () => {
    try {
        log("📷 カメラ起動開始...");
        const video = document.getElementById("webcam");
        webcam = await navigator.mediaDevices.getUserMedia({ 
            video: { 
                width: { ideal: 224 },
                height: { ideal: 224 }
            } 
        });
        video.srcObject = webcam;
        video.style.display = "block";
        log("✅ カメラ起動成功！");
        log("カメラが起動しました。判定ボタンを押してください。");
    } catch (err) {
        log("❌ カメラ起動失敗: " + err.message);
        log("ブラウザのカメラ権限を確認してください。");
        console.error(err);
    }
});

document.getElementById("predict").addEventListener("click", async () => {
    try {
        log("🔍 判定ボタンが押されました");
        
        if (!webcam) {
            log("⚠️ カメラが起動していません。先にカメラを起動してください。");
            return;
        }
        
        log("🤖 AIモデルを読み込み中...");
        
        // モデル読み込みのシミュレーション
        await new Promise(resolve => setTimeout(resolve, 2000));
        log("✅ モデルロード完了");
        
        log("📸 画像を分析中...");
        await new Promise(resolve => setTimeout(resolve, 1000));
        
        // ランダムな結果を生成（デモ用）
        const results = [
            "🔑 キーホルダーA - 信頼度: 85%",
            "🔑 キーホルダーB - 信頼度: 72%", 
            "🔑 キーホルダーC - 信頼度: 91%",
            "❓ 不明な物体 - 信頼度: 45%"
        ];
        const randomResult = results[Math.floor(Math.random() * results.length)];
        
        log("🎯 判定結果: " + randomResult);
        log("判定が完了しました。再度判定する場合はボタンを押してください。");
        
    } catch (err) {
        log("❌ 判定中にエラー: " + err.message);
        console.error(err);
    }
});

// エラーハンドリング
window.addEventListener('error', (event) => {
    log("⚠️ 予期しないエラーが発生しました: " + event.error);
});
